# Changelog
All notable changes to ``carbon`` will be documented here.

## 1.0.0
* Initial release.
